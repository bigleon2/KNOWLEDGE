# REASONING — Processus Chain-of-Thought Détaillé

## MÉTHODOLOGIE EN 7 ÉTAPES

### ÉTAPE 1 : COMPRÉHENSION (5-10 min)
**Objectif** : Saisir globalement le projet
**Actions** :
1. Lire l'ensemble du matériel fourni
2. Identifier le type de projet
3. Noter l'objectif principal en une phrase
4. Lister les contraintes majeures
5. Déterminer le niveau de complexité
**Livrable** : Résumé exécutif du projet

### ÉTAPE 2 : DÉCOMPOSITION (5 min)
**Objectif** : Structurer mentalement le projet
**Actions** :
1. Identifier les composants principaux
2. Cartographier les dépendances
3. Repérer les patterns récurrents
4. Classer les informations par catégorie
**Livrable** : Carte mentale des éléments

### ÉTAPE 3 : EXTRACTION (10-15 min)
**Objectif** : Extraire systématiquement tous les éléments
**Checklist** :
- [ ] Objectif principal + sous-objectifs
- [ ] Règles absolues + limitations techniques
- [ ] Étapes successives + décisions prises
- [ ] Format de sortie + blocs/sections
- [ ] Style + langue + niveau de détail
- [ ] Scripts + plateformes + bibliothèques
**Livrable** : Liste exhaustive des éléments extraits

### ÉTAPE 4 : STRUCTURATION (10 min)
**Objectif** : Organiser les éléments dans l'architecture du kit
**Mapping** :
- `config.yaml` : Paramètres globaux + schemas
- `00_System.md` : Comportement général
- `01_Role.md` : Identité et expertise
- `02_Constraints.md` : Règles absolues
- `03_Context.md` : Informations projet
- `04_Structure.md` : Architecture de sortie
- `05_Formatting.md` : Style et présentation
- `06_QualityControl.md` : Validation
- `07_Reasoning.md` : Processus COT
**Livrable** : Plan de structuration complet

### ÉTAPE 5 : GÉNÉRATION (20-30 min)
**Objectif** : Produire tous les fichiers du kit
**Ordre** :
1. README.md
2. config/config.yaml
3. prompts/00_System.md à 07_Reasoning.md
4. examples/
5. tests/test_cases.md
6. build/prompt_final.md
**Livrable** : Kit complet généré

### ÉTAPE 6 : VALIDATION (10 min)
**Objectif** : Vérifier la qualité et la cohérence
**Checklist** :
- [ ] Tous les fichiers sont présents
- [ ] Références croisées correctes
- [ ] Pas de contradictions entre fichiers
- [ ] prompt_final.md est directement utilisable
- [ ] Exemples sont pertinents et concrets
- [ ] Test cases couvrent les scénarios principaux
**Livrable** : Rapport de validation

### ÉTAPE 7 : AMÉLIORATION (5 min)
**Objectif** : Proposer des évolutions
**Actions** :
1. Identifier 3 points d'amélioration
2. Noter les cas limites non couverts
3. Suggérer des tests additionnels
4. Documenter les évolutions futures possibles
**Livrable** : Recommandations d'amélioration
