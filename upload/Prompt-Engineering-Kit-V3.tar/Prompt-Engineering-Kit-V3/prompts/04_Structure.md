# STRUCTURE — Organisation de la Sortie

## Architecture Générale
La sortie doit être organisée selon une structure modulaire en blocs principaux, chacun ayant une responsabilité unique et clairement définie.

## Bloc 1 : Portrait/Contexte Principal
- **Position** : En haut à gauche
- **Contenu** : Image/photo originale (sans modification) ou contexte principal du projet
- **Format** : Taille grande (40% de l'espace), haute résolution
- **Règle absolue** : Ne jamais générer de nouvelle image

## Bloc 2 : Saison/Classification
- **Position** : En haut à droite
- **Contenu** : Catégorie principale, sous-catégorie si applicable, pastilles de couleurs/icônes représentatives
- **Format** : Titre + 3-4 éléments visuels

## Bloc 3 : Caractéristiques
- **Position** : Centre droit
- **Contenu** : Liste des caractéristiques clés, icônes illustratives, descriptions courtes
- **Format** : 4-6 items avec icônes

## Bloc 4 : Recommandations Principales
- **Position** : Centre
- **Contenu** : Recommandations validées (✓), déconseillé (✗), justifications courtes
- **Format** : Listes avec symboles

## Bloc 5 : Comparaisons Positives
- **Position** : Milieu gauche
- **Contenu** : 4-6 exemples visuels, couleurs/éléments qui fonctionnent, légendes courtes
- **Format** : Grille d'images avec pastilles

## Bloc 6 : Comparaisons Négatives
- **Position** : Milieu droit
- **Contenu** : 4 exemples visuels, éléments à éviter, explications courtes
- **Format** : Grille d'images avec pastilles

## Bloc 7 : Palettes Détaillées
- **Position** : Bas gauche
- **Contenu** : Familles de couleurs/éléments, nuanciers complets, noms des teintes
- **Format** : Tableaux organisés par famille

## Bloc 8 : Exemples Pratiques
- **Position** : Bas droit
- **Contenu** : 3 exemples concrets d'application, descriptions détaillées, conseils d'utilisation
- **Format** : Illustrations + texte

## Hiérarchie Visuelle
- **Niveau 1 (Prioritaire)** : Blocs 1, 2, 4
- **Niveau 2 (Secondaire)** : Blocs 3, 5, 6
- **Niveau 3 (Détails)** : Blocs 7, 8
