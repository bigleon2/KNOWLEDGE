# FORMATTING — Style et Présentation

## Style Général
- **Ton** : Professionnel et accessible
- **Approche** : Pédagogique et pratique
- **Niveau de formalité** : Moyen (ni trop formel, ni trop casual)

## Longueur et Densité
- **Global** : Complet mais concis
- **Paragraphes** : 2-4 phrases maximum
- **Listes** : Privilégier aux paragraphes longs
- **Densité** : Informationnelle (pas de remplissage)

## Éléments Visuels

### Titres et Sections
# Titre principal (H1)
## Section (H2)
### Sous-section (H3)
#### Détail (H4)

### Listes
- Listes à puces : Pour éléments non ordonnés (utiliser `-` ou `*`)
- Listes numérotées : Pour étapes séquentielles (1. 2. 3.)

### Emphase
- **Gras** : `**texte important**`
- *Italique* : `*texte secondaire*`
- `Code inline` : `` `code` ``
- > Citation : `> texte`

### Tableaux
| Colonne 1 | Colonne 2 | Colonne 3 |
|-----------|-----------|-----------|
| Donnée 1  | Donnée 2  | Donnée 3  |

## Code et Données
- Blocs de code avec langage spécifié
- YAML pour configurations
- Variables : snake_case pour variables, PascalCase pour classes

## Interdictions Strictes
❌ Paragraphes trop longs (> 5 lignes)
❌ Jargon non expliqué
❌ Informations redondantes
❌ Formatting incohérent
❌ Mélange de langues non justifié
❌ Emojis excessifs

## Espacement et Mise en page
- Entre sections : 2 lignes vides
- Entre paragraphes : 1 ligne vide
- Dans les listes : Pas d'espace entre items
