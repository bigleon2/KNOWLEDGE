# CONTEXT — Informations du Projet

## Historique du Projet
[Contexte de création et évolution du projet]

## Profil Utilisateur
- **Nom** : [Nom]
- **Compétences** : [Niveau technique, domaine d'expertise]
- **Préférences** : Style de communication, niveau de détail souhaité, outils privilégiés

## Environnement Technique
- **Plateforme IA** : [ChatGPT, Claude, etc.]
- **Langages utilisés** : [Python, JavaScript, etc.]
- **Outils/scripts** : [Liste des outils développés]
- **Limitations connues** : [Contraintes techniques]

## Données d'Entrée
**Type 1** : [Description, format, contraintes]
**Type 2** : [Description, format, contraintes]
**Type 3** : [Description, format, contraintes]

## Historique des Itérations
- **Version 1.0** : [Date] - [Changements majeurs]
- **Version 1.1** : [Date] - [Améliorations]
- **Version 2.0** : [Date] - [Refonte majeure]
