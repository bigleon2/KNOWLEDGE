# CONTRAINTES — Règles Absolues (Zéro Tolérance)

## RÈGLE 1 : PRÉSERVATION DE L'ORIGINAL
**Description** : Ne jamais modifier ou dénaturer le projet original fourni par l'utilisateur.
- ✅ **Autorisé** : Structurer l'information existante, clarifier les concepts ambigus, organiser selon l'architecture du kit
- ❌ **Interdit** : Inventer des éléments non présents, modifier les décisions prises, changer les contraintes établies

## RÈGLE 2 : COMPLÉTUDE DES FICHIERS
**Description** : Tous les fichiers de la structure doivent être générés, même si certains sont vides.
- ✅ **Autorisé** : Créer un fichier avec contenu minimal si information manquante, ajouter des commentaires "[À COMPLÉTER]"
- ❌ **Interdit** : Omettre un fichier de la structure, générer un fichier vide sans notification

## RÈGLE 3 : COHÉRENCE DES RÉFÉRENCES
**Description** : Les références croisées entre fichiers doivent être exactes et fonctionnelles.
- ✅ **Autorisé** : Utiliser des chemins relatifs standards, créer des liens Markdown valides
- ❌ **Interdit** : Référencer un fichier inexistant, utiliser des chemins absolus, créer des liens brisés

## RÈGLE 4 : RESPECT DES SCHEMAS
**Description** : Les schemas d'entrée/sortie définis dans config.yaml doivent être strictement respectés.
- ✅ **Autorisé** : Valider la conformité aux schemas, signaler les écarts
- ❌ **Interdit** : Générer un output non conforme au schema, ignorer les champs requis

## RÈGLE 5 : APPLICATION DU CHAIN-OF-THOUGHT
**Description** : Le processus en 7 étapes doit être suivi rigoureusement pour chaque conversion.
- ✅ **Autorisé** : Prendre le temps nécessaire pour chaque étape, revenir en arrière si nécessaire
- ❌ **Interdit** : Sauter une étape, mélanger les étapes, accélérer au détriment de la qualité

## RÈGLE 6 : QUALITÉ DES EXEMPLES
**Description** : Les exemples fournis doivent être concrets, pertinents et couvrir les cas nominaux et limites.
- ✅ **Autorisé** : Adapter les exemples au projet spécifique, inclure des cas d'erreur courants
- ❌ **Interdit** : Utiliser des exemples génériques non adaptés, omettre les cas limites

## Gestion des Cas Limites
- **Cas 1 : Projet incomplet** → Générer le kit avec placeholders et demander compléments
- **Cas 2 : Contradictions dans le projet** → Identifier et proposer résolution
- **Cas 3 : Informations ambiguës** → Présenter plusieurs interprétations et demander validation
