# QUALITY CONTROL — Système de Validation

## Checklist Pré-Génération
- ✓ Toutes les informations requises sont présentes
- ✓ Le contexte est clair et complet
- ✓ Les contraintes sont bien définies
- ✓ Les exemples sont pertinents

## Checklist Post-Génération

### Complétude (10 points)
- ✓ README.md présent et complet
- ✓ config/config.yaml valide (syntaxe YAML)
- ✓ 8 fichiers prompts présents (00 à 07)
- ✓ examples/ avec au moins 3 exemples
- ✓ tests/test_cases.md avec scénarios variés
- ✓ build/prompt_final.md fonctionnel
- ✓ Aucun fichier vide sans notification
- ✓ Tous les schemas définis
- ✓ Références croisées valides
- ✓ Versionning cohérent

### Cohérence (8 points)
- ✓ Terminologie uniforme dans tous les fichiers
- ✓ Pas de contradictions entre contraintes
- ✓ Les exemples correspondent aux spécifications
- ✓ Les tests couvrent les contraintes
- ✓ Le prompt_final reflète tous les modules
- ✓ Les schemas input/output sont alignés
- ✓ La structure suit l'architecture définie
- ✓ Le style est cohérent partout

### Qualité (7 points)
- ✓ Langage clair et sans ambiguïté
- ✓ Formatting Markdown correct
- ✓ YAML syntaxiquement valide
- ✓ Code fonctionnel (si applicable)
- ✓ Exemples concrets et réalistes
- ✓ Tests pertinents et exécutables
- ✓ Documentation complète

**Score minimum requis** : 22/25 (88%)

## Points de Vigilance Spécifiques
- ⚠️ Piège 1 : Génération d'images non autorisée
- ⚠️ Piège 2 : Oubli du Chain-of-Thought
- ⚠️ Piège 3 : Schemas manquants
- ⚠️ Piège 4 : Exemples génériques
- ⚠️ Piège 5 : Tests insuffisants

## Auto-Correction
Si un critère n'est pas respecté :
1. Identifier l'erreur
2. Analyser la cause
3. Corriger
4. Valider

## Score de qualité final
- **25/25** : Parfait ✅
- **22-24/25** : Excellent ✓
- **20-21/25** : Acceptable (avec réserves) ⚠️
- **< 20/25** : À reprendre ❌
