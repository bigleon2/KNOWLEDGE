# OUTPUT EXAMPLE — Exemple de Sortie Attendue

## Structure du Kit Généré

```text
Analyse-Colorimetrie-Prompt-Kit/
│
├── README.md
├── config/
│   └── config.yaml
├── prompts/
│   ├── 00_System.md
│   ├── 01_Role.md
│   ├── 02_Constraints.md
│   ├── 03_Context.md
│   ├── 04_Structure.md
│   ├── 05_Formatting.md
│   ├── 06_QualityControl.md
│   └── 07_Reasoning.md
├── examples/
│   ├── input_example.md
│   ├── output_example.md
│   └── few_shot_examples.md
├── tests/
│   └── test_cases.md
└── build/
    └── prompt_final.md
```

## Extrait du README.md

```markdown
# Analyse Colorimétrique Premium — Prompt Engineering Kit

**Version** : 2.0
**Date** : 2024

## 📋 Vue d'ensemble
Système complet d'analyse colorimétrique personnelle générant des
infographies premium basées sur les caractéristiques physiques.

## 🎯 Objectif
Convertir une photo avec masque vert en infographie colorimétrique
complète avec 8 blocs structurés (saison, palettes, tenues).
```

## Résultat Final Attendu

Une infographie premium contenant :
- ✅ Portrait original préservé
- ✅ Saison déterminée (ex: Printemps Lumineux)
- ✅ Caractéristiques listées (cheveux, peau, yeux)
- ✅ Métaux recommandés (Or, Or rose, Cuivre)
- ✅ 4 couleurs flatteuses avec exemples visuels
- ✅ 4 couleurs à éviter avec exemples visuels
- ✅ Palettes complètes organisées par famille
- ✅ 3 tenues modernes coordonnées

**Qualité** : Aspect magazine, design éditorial haut de gamme
