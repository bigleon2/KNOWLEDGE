# FEW-SHOT EXAMPLES — Exemples de Référence

## EXEMPLE 1 : Projet d'Analyse Colorimétrique (Cas Nominal)

### Input
Contexte: Analyse colorimétrique personnelle
Objectif: Générer une infographie premium avec 8 blocs

Conversations:
- Itération 1: Script OpenCV → Erreur fenêtre graphique
- Itération 2: Solution Tkinter → Fonctionnel
- Itération 3: Optimisations → Redimensionnement auto

Contraintes identifiées:
- Ne jamais modifier le visage
- Tenues modernes uniquement (COS, Sézane)
- Utiliser photo originale dans Block 1
- Masque vert pour analyse uniquement

### Output Attendu
Structure complète du kit avec :
- config.yaml avec schemas d'entrée/sortie
- 8 modules de prompts (00_System à 07_Reasoning)
- Exemples concrets du masquage
- Test cases pour validation
- Prompt final assemblé en XML

---

## EXEMPLE 2 : Projet Incomplet (Cas Limite)

### Input
Contexte: Analyse de données marketing
Objectif: [non spécifié]
Résultats: [aucun fourni]

### Output Attendu
❌ INFORMATIONS MANQUANTES

Pour générer un Prompt Engineering Kit complet, j'ai besoin de :
1. ❌ Objectif précis du projet
2. ❌ Conversations/interactions avec l'IA
3. ❌ Résultats obtenus (code, analyses, outputs)

---

## EXEMPLE 3 : Projet avec Contradictions (Cas Complexe)

### Input
Contraintes identifiées:
- "Le prompt doit être très court"
- "Le prompt doit être exhaustif et détaillé"
- "Utiliser uniquement du texte"
- "Inclure des images et graphiques"

### Output Attendu
⚠️ CONTRADICTIONS DÉTECTÉES

**Contradiction 1** :
- Contrainte A: "Le prompt doit être très court"
- Contrainte B: "Le prompt doit être exhaustif et détaillé"
→ Proposition: Définir un niveau de détail moyen avec sections optionnelles

**Contradiction 2** :
- Contrainte A: "Utiliser uniquement du texte"
- Contrainte B: "Inclure des images et graphiques"
→ Proposition: Texte principal + annexes visuelles optionnelles
