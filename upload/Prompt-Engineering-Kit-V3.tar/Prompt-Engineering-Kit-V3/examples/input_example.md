# INPUT EXAMPLE — Exemple de Données d'Entrée

## Contexte du Projet

**Nom** : Analyse Colorimétrique Premium
**Domaine** : Conseil en image / Beauté
**Objectif** : Générer une infographie colorimétrique personnalisée

## Description Détaillée

Ce projet permet d'analyser les caractéristiques physiques d'une personne (cheveux, peau, yeux) et de déterminer sa saison colorimétrique pour générer une infographie premium avec recommandations personnalisées.

## Conversations/Interactions

### Itération 1
**Problème** : Script OpenCV avec fenêtre graphique
**Erreur** : `cv2.namedWindow` non implémenté sur Windows
**Solution** : Abandon d'OpenCV pour l'interface

### Itération 2
**Solution** : Migration vers Tkinter + Pillow
**Résultat** : Interface fonctionnelle
**Amélioration** : Masquage manuel des vêtements

### Itération 3
**Optimisation** : Redimensionnement automatique
**Ajout** : Gestion des grandes images
**Feature** : Conversion coordonnées souris

## Résultats Obtenus

### Code
- `agent_tkinter.py` : Script de masquage (200 lignes)
- Gestion du pinceau réglable
- Sauvegarde PNG haute qualité
- Interface responsive

### Outputs
- Image masquée : `ma_photo_prete.png`
- Image originale conservée : `ma_photo.jpg`
- Infographie générée : 8 blocs structurés

## Contraintes Identifiées

### Contraintes absolues
1. **Ne jamais modifier le visage** : Préserver 100% des traits
2. **Tenues modernes uniquement** : Style COS, Sézane, Arket
3. **Photo originale dans Block 1** : Jamais de génération
4. **Masque vert pour analyse** : Ignorer le vert fluo

### Limitations techniques
- Tkinter uniquement (pas d'OpenCV GUI)
- Images < 4000px (redimensionnement si besoin)
- Format PNG pour qualité maximale

## Données d'Entrée

### Type 1 : Photo originale
- Format : JPG ou PNG
- Taille : 500px - 4000px
- Contenu : Portrait avec vêtements visibles

### Type 2 : Photo masquée
- Format : PNG (recommandé)
- Masque : Vert fluo #00FF00
- Zone masquée : Vêtements uniquement
