# TEST CASES — Validation du Kit

## TEST 1 : Données manquantes

### Input
```
Contexte: Projet d'analyse de données
Conversations: []
Résultats: null
```

### Attendu
- Message d'erreur clair listant les champs manquants
- Demande de compléments d'information

### Critères de succès
- ✓ Message explicite
- ✓ Liste des champs requis

---

## TEST 2 : Données incomplètes

### Input
```
Contexte: Création de site web
Objectif: Site vitrine
Conversations: ["Itération 1: maquette validée"]
Contraintes: non spécifiées
```

### Attendu
- Kit généré partiellement
- Sections manquantes marquées "[À COMPLÉTER]"

### Critères de succès
- ✓ Fichiers présents mais incomplets signalés
- ✓ Placeholders appropriés

---

## TEST 3 : Données complexes (Multi-itérations)

### Input
Projet complet avec :
- 10+ conversations
- 5 itérations majeures
- 3 scripts différents
- 15 contraintes identifiées

### Attendu
- Kit complet et structuré
- Toutes les itérations documentées

### Critères de succès
- ✓ Exhaustivité
- ✓ Cohérence

---

## TEST 4 : Contraintes contradictoires

### Input
```
Contraintes:
- "Format très court"
- "Format très détaillé"
```

### Attendu
- Détection automatique des contradictions
- Proposition de résolution

### Critères de succès
- ✓ Contradictions identifiées
- ✓ Solutions proposées

---

## TEST 5 : Projet très simple

### Input
```
Contexte: Génération de texte
Objectif: Écrire un email
```

### Attendu
- Kit minimal mais complet
- Pas de complexité inutile

---

## TEST 6 : Performance (Grand projet)

### Input
Projet avec 50+ pages de conversations et 100+ contraintes

### Attendu
- Traitement complet sans troncature

---

## TEST 7 : Spécificités techniques

### Input
```
Projet: Système embarqué
Contraintes:
- Mémoire limitée (64KB)
- Temps réel strict
- Langage C uniquement
```

### Attendu
- Prise en compte des contraintes techniques
- Exemples pertinents au domaine
